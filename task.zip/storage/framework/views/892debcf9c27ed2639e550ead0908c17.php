<?php $__env->startSection('content'); ?>
    <div class="container-fluid pt-3">
        <div class="row gx-1">
            <div class="col-sm-12 col-md-12 col-lg-8">
                <div class="m-3 border">
                    <div class="p-3 border bg-light">
                        <span>Product Section</span>
                    </div>
                    <div class="px-3 pt-3">
                        <input class="form-control me-2 productSearch" name="search" type="text" placeholder="Enter Product Name / SKU" aria-label="Search">
                        <div class="request__product">

                        </div>
                    </div>
                    <div class="p-3">
                        <div class="row row-cols-1 row-cols-md-3 g-4 productShow">
                            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="col-sm-6 col-md-3 col-lg-2 addToCart" data-product_id="<?php echo e($product->id); ?>">
                                    <div class="card">
                                        <div class="text-center pt-3">
                                            <img src="<?php echo e(asset('assets/images/product/'.$product->image)); ?>" class="card-img-top" alt="...">
                                            <div class="card-body">
                                                <span class="card-title"><?php echo e(Str::limit($product->name, 10)); ?></span><br>
                                                <span class="card-title"><?php if($product->discount < 0): ?><?php echo e($product->selling_price); ?> <?php else: ?> <?php echo e($product->selling_price - $product->discount); ?><?php endif; ?></span> <?php if($product->discount > 0): ?><del class="del-test"><?php echo e($product->selling_price); ?></del><?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class='text-muted text-center' colspan='100%'>No Product Add</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php if($products->hasPages()): ?>
                    <div class='card-footer'>
                        <?php echo e($products->links()); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="col-sm-12 col-md-12 col-lg-4">
                <div class="m-3 border">
                    <div class="p-3 border bg-light">
                        <span>Billing Section</span>
                    </div>

                    <div class="p-3">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th scope="col">Item</th>
                                    <th scope="col">qty</th>
                                    <th scope="col">Price</th>
                                    <th class="text-center" scope="col">Action</th>
                                </tr>
                                </thead>
                                <tbody class="table_body">
                                </tbody>
                            </table>
                        </div>

                        <div class="cal-area">
                            <div class="d-flex justify-content-between">
                                <span>Subtotal : </span>
                                <span><span class="subTotal">0</span><span>TK</span></span>
                            </div>

                            <div class="d-flex justify-content-between">
                                <span>Product Discount : </span>
                                <span><span class="discount">0 </span><span>TK</span></span>
                            </div>

                            <div class="d-flex justify-content-between">
                                <span>Tax : </span>
                                <span><span class="tax">0</span><span>TK</span></span>
                            </div>

                            <div class="d-flex justify-content-between">
                                <span>Total : </span>
                                <span><span class="fw-bold total">0</span><span>TK</span></span>
                            </div>
                        </div>

                        <div class="submit gap-2 mt-3 d-flex justify-content-between">
                            <button class="btn btn-danger emptyCart" type="button">Empty Cart</button>
                            <button class="btn btn-success text-end placeOrder" type="button">Place Order</button>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>







<?php echo $__env->make('template.pos.pos_layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\task-app\app\views/template/pos/pos_template/index.blade.php ENDPATH**/ ?>