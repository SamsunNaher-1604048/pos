<div id="app-sidepanel" class="app-sidepanel">
    <div id="sidepanel-drop" class="sidepanel-drop"></div>
    <div class="sidepanel-inner d-flex flex-column">
        <a href="#" id="sidepanel-close" class="sidepanel-close d-xl-none">&times;</a>
        <div class="app-branding">
            <a class="app-logo" href="index.html"><img class="logo-icon me-2" src="<?php echo e(asset('assets/images/app-logo.svg')); ?>" alt="logo"><span class="logo-text">TASK</span></a>

        </div><!--//app-branding-->

        <nav id="app-nav-main" class="app-nav app-nav-main flex-grow-1">
            <ul class="app-menu list-unstyled accordion" id="menu-accordion">

                <li class="nav-item">
                    <a class="nav-link active" href="<?php echo e(route('dashboard')); ?>">
                        <span class="nav-link-text">Overview</span>
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('product.index')); ?>">
                        <span class="nav-link-text">Product</span>
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('order.index')); ?>">
                        <span class="nav-link-text">Orders</span>
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" target="_blank" href="<?php echo e(route('pos.show')); ?>">
                        <span class="nav-link-text">POS</span>
                    </a>
                </li>

            </ul>
        </nav>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\task-app\app\views/includes/nav.blade.php ENDPATH**/ ?>