<!DOCTYPE html>
<html lang="en">
<head>
    <title>ThemeLooks Task</title>

    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="description" content="Portal - Bootstrap 5 Admin Dashboard Template For Developers">
    <meta name="author" content="Xiaoying Riley at 3rd Wave Media">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <link rel="shortcut icon" href="favicon.ico">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/custom.css')); ?>">

    <!-- FontAwesome JS-->
    <script defer src="<?php echo e(asset('assets/plugins/fontawesome/js/all.min.js')); ?>"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <!-- App CSS -->
    <link id="theme-style" rel="stylesheet" href="<?php echo e(asset('assets/css/portal.css')); ?>">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>


</head>

<body class="app">
<!--//app-header-->

<header class="app-header fixed-top">
    <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
</header>


<div class="app-wrapper">
    <?php echo $__env->yieldContent('content'); ?>
</div><!--//app-wrapper-->



<script>

    "use strict";
    toastr.options = {
        "closeButton": false,
        "debug": false,
        "newestOnTop": false,
        "progressBar": true,
        "positionClass": "toast-top-right",
        "preventDuplicates": true,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "3000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    }


    <?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emsg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    toastr.error('<?php echo e($emsg); ?>');
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <?php if(session()->has('alert')): ?>
    <?php if(session('alert')[0] == 'danger'): ?>
    toastr.error('<?php echo e(session('alert')[1]); ?>');
    <?php elseif(session('alert')[0] == 'success'): ?>
    toastr.success('<?php echo e(session('alert')[1]); ?>');
    <?php else: ?>
    toastr.error('<?php echo e(session('alert')[1]); ?>');
    <?php endif; ?>
    <?php endif; ?>
    function systemAlert(type,message) {
        if (type == 'danger') {
            toastr.error(message);
        } else if ($type == 'success') {
            toastr.success(message);
        } else {
            toastr.error(message);
        }
    }
</script>
<!-- Javascript -->
<script src="<?php echo e(asset('assets/plugins/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/bootstrap/js/bootstrap.min.js')); ?>"></script>

<!-- Charts JS -->
<script src="<?php echo e(asset('assets/plugins/chart.js/chart.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/index-charts.js')); ?>"></script>

<!-- Page Specific JS -->
<script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\task-app\app\views/layouts/master.blade.php ENDPATH**/ ?>