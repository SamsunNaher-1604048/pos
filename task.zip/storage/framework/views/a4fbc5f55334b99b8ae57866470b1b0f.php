;
<?php $__env->startSection('content'); ?>

    <div class="container">
        <form action="<?php echo e(route('order.filter')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="row d-flex flex-row-reverse">
                <div class="col-auto mt-4">
                    <button type="submit" class="btn btn-success">filter</button>
                </div>
                <div class="col-auto">
                    <label for="start">Start Date:</label>
                    <input type="date" class="form-control" placeholder="Start Date" name="start" required>
                </div>
                <div class="col-auto">
                    <label for="end">End Date:</label>
                    <input type="date" class="form-control" placeholder="End Date" name="end" required>
                </div>
            </div>
        </form>
    </div>

    <div class="product_table m-3">
        <table class="table">
            <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Total Order</th>
                <th scope="col">SubTotal</th>
                <th scope="col">Total Discount</th>
                <th scope="col">Total Tax</th>
                <th scope="col">GrandTotal</th>
            </tr>
            </thead>
            <tbody>

            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($order->id); ?></td>
                    <td><?php echo e($order->quantity); ?></td>
                    <td><?php echo e($order->sub_total); ?></td>
                    <td><?php echo e($order->total_discount); ?></td>
                    <td><?php echo e($order->total_tax); ?></td>
                    <td><?php echo e($order->grand_total); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td class='text-muted text-center' colspan='100%'>No Order</td>
                </tr>
            <?php endif; ?>

            </tbody>
        </table>
        <?php if($orders->hasPages()): ?>
            <div class='card-footer'>
                <?php echo e($orders->links()); ?>

            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\task-app\app\views/template/order/index.blade.php ENDPATH**/ ?>