;
<?php $__env->startSection('content'); ?>
    <div class="d-flex p-2">
        <a class="btn btn-success" href="<?php echo e(route('product.create')); ?>">Add Product</a>
    </div>

    <div class="product_table m-3">
        <table class="table">
            <thead>
            <tr>
                <th scope="col">Image</th>
                <th scope="col">Product Name</th>
                <th scope="col">Quantity</th>
                <th scope="col">Selling Price</th>
                <th scope="col">Purchase Price</th>
                <th scope="col">Discount</th>
                <th scope="col">Action</th>
            </tr>
            </thead>
            <tbody>

            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><img class="image" src="<?php echo e(asset('assets/images/product/'.$product->image)); ?>" alt="Image"></td>
                    <td><?php echo e($product->name); ?></td>
                    <td><?php echo e($product->product_unit_value); ?><?php echo e($product->product_unit); ?></td>
                    <td><?php echo e($product->selling_price); ?></td>
                    <td><?php echo e($product->purchase_price); ?></td>
                    <td><?php echo e($product->discount); ?></td>
                    <td>
                        <a type="button" class="btn btn-success" href="<?php echo e(route('product.edit',$product->id)); ?>">Edit</a>
                        <a type="button" class="btn btn-danger custom_btn" href ="<?php echo e(route('product.delete',$product->id)); ?>">Delete</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td class='text-muted text-center' colspan='100%'>No Product Add</td>
                </tr>
            <?php endif; ?>

            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\task-app\app\views/template/product/index.blade.php ENDPATH**/ ?>