<!DOCTYPE html>

<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" href="<?php echo e(asset('assets/css/pos.css')); ?>">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
      <link rel= "stylesheet" href= "https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css" >
      <title>ThemeLooks Pos</title>
  </head>

<body>
    <header class="header">
        <div class="container-fluid">
            <div class="row p-2 align-items-center">
                <div class="get_date">
                    <p class="fs-5">Today Date: <?php echo date("Y/m/d") ?></p>
                </div>
            </div>
        </div>
    </header>
    <div class="container-fluid pt-3">
        <div class="row gx-1">
            <div class="col-sm-12 col-md-12 col-lg-8">
                <div class="m-3 border">
                    <div class="p-3 border bg-light">
                        <span>Product Section</span>
                    </div>
                    <div class="px-3 pt-3">
                        <form class="d-flex">
                            <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                        </form>
                    </div>
                    <div class="p-3">
                        <div class="row row-cols-1 row-cols-md-3 g-4">
                            <div class="col-sm-6 col-md-3 col-lg-2">
                                <div class="card">
                                    <div class="text-center pt-3">
                                        <img src="<?php echo e(asset('assets/images/background/background-1.jpg')); ?>" class="card-img-top" alt="...">
                                        <div class="card-body">
                                            <span class="card-title">Card title</span>
                                            <span class="card-title">6523 $</span> <del class="del-test">4527 $</del>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-3 col-lg-2">
                                <div class="card">
                                    <div class="text-center pt-3">
                                        <img src="<?php echo e(asset('assets/images/background/background-1.jpg')); ?>" class="card-img-top" alt="...">
                                        <div class="card-body">
                                            <span class="card-title">Card title</span>
                                            <span class="card-title">6523 $</span> <del class="del-test">4527 $</del>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-3 col-lg-2">
                                <div class="card">
                                    <div class="text-center pt-3">
                                        <img src="<?php echo e(asset('assets/images/background/background-1.jpg')); ?>" class="card-img-top" alt="...">
                                        <div class="card-body">
                                            <span class="card-title">Card title</span>
                                            <span class="card-title">6523 $</span> <del class="del-test">4527 $</del>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-3 col-lg-2">
                                <div class="card">
                                    <div class="text-center pt-3">
                                        <img src="<?php echo e(asset('assets/images/background/background-1.jpg')); ?>" class="card-img-top" alt="...">
                                        <div class="card-body">
                                            <span class="card-title">Card title</span>
                                            <span class="card-title">6523 $</span> <del class="del-test">4527 $</del>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-3 col-lg-2">
                                <div class="card">
                                    <div class="text-center pt-3">
                                        <img src="<?php echo e(asset('assets/images/background/background-1.jpg')); ?>" class="card-img-top" alt="...">
                                        <div class="card-body">
                                            <span class="card-title">Card title</span>
                                            <span class="card-title">6523 $</span> <del class="del-test">4527 $</del>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-3 col-lg-2">
                                <div class="card">
                                    <div class="text-center pt-3">
                                        <img src="<?php echo e(asset('assets/images/background/background-1.jpg')); ?>" class="card-img-top" alt="...">
                                        <div class="card-body">
                                            <span class="card-title">Card title</span>
                                            <span class="card-title">6523 $</span> <del class="del-test">4527 $</del>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-3 col-lg-2">
                                <div class="card">
                                    <div class="text-center pt-3">
                                        <img src="<?php echo e(asset('assets/images/background/background-1.jpg')); ?>" class="card-img-top" alt="...">
                                        <div class="card-body">
                                            <span class="card-title">Card title</span>
                                            <span class="card-title">6523 $</span> <del class="del-test">4527 $</del>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12 col-md-12 col-lg-4">
                <div class="m-3 border">
                    <div class="p-3 border bg-light">
                        <span>Billing Section</span>
                    </div>
                    <div class="p-3">
                        <div class="table-responsive">
                           <table class="table">
                               <thead>
                                   <tr>
                                       <th scope="col">Item</th>
                                       <th scope="col">qty</th>
                                       <th scope="col">Price</th>
                                       <th class="text-center" scope="col">Action</th>
                                   </tr>
                               </thead>
                               <tbody>
                                   <tr>
                                       <td>
                                           <img src="<?php echo e(asset('assets/images/background/background-1.jpg')); ?>" alt="" height="30px" width="30px">
                                           <span class="product-name">Product Name....</span>
                                       </td>
                                       <td class="product-qty">
                                           <label>
                                               <input type="number" class="form-control" value="0">
                                           </label>
                                       </td>
                                       <td>400 $</td>
                                       <td class="text-center">
                                           <button class="btn btn-danger btn-sm"><i class="las la-trash-alt"></i></button>
                                       </td>
                                   </tr>
                                   <tr>
                                       <td>
                                           <img src="<?php echo e(asset('assets/images/background/background-1.jpg')); ?>" alt="" height="30px" width="30px">
                                           <span class="product-name">Product Name....</span>
                                       </td>
                                       <td class="product-qty">
                                           <label>
                                               <input type="number" class="form-control" value="0">
                                           </label>
                                       </td>
                                       <td>400 $</td>
                                       <td class="text-center">
                                           <button class="btn btn-danger btn-sm"><i class="las la-trash-alt"></i></button>
                                       </td>
                                   </tr>
                                   <tr>
                                       <td>
                                           <img src="<?php echo e(asset('assets/images/background/background-1.jpg')); ?>" alt="" height="30px" width="30px">
                                           <span class="product-name">Product Name....</span>
                                       </td>
                                       <td class="product-qty">
                                           <label>
                                               <input type="number" class="form-control" value="0">
                                           </label>
                                       </td>
                                       <td>400 $</td>
                                       <td class="text-center">
                                           <button class="btn btn-danger btn-sm"><i class="las la-trash-alt"></i></button>
                                       </td>
                                   </tr>
                               </tbody>
                           </table>
                        </div>

                        <div class="cal-area">
                            <div class="d-flex justify-content-between">
                                <span>Subtotal : </span>
                                <span>123 $ </span>
                            </div>

                            <div class="d-flex justify-content-between">
                                <span>Product Discount : </span>
                                <span>123 $ </span>
                            </div>

                            <div class="d-flex justify-content-between">
                                <span>Tax : </span>
                                <span>123 $ </span>
                            </div>

                            <div class="d-flex justify-content-between">
                                <span>Total : </span>
                                <span class="fw-bold">123 $ </span>
                            </div>
                        </div>

                        <div class="submit d-grid gap-2 mt-3">
                            <button class=" custom_btn" type="button">Button</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>


</body>
</html>


<?php /**PATH C:\xampp\htdocs\task-app\app\views/template/pos/posTemplate/index.blade.php ENDPATH**/ ?>