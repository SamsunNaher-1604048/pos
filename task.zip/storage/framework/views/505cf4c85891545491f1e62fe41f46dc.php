<?php $__empty_1 = true; $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr class="table_row">
        <td>
            <img src="<?php echo e(asset('assets/images/product/'.$data->product->image)); ?>" alt="" height="30px" width="30px">
            <span class="product-name"><?php echo e($data->product->name); ?></span>
        </td>
        <td class="product-qty">
            <label>
                <input type="number" class="form-control productQuantity" data-cart_id = <?php echo e($data->id); ?> value=<?php echo e($data->quantity); ?>>
            </label>
        </td>
        <td><?php echo e($data->product->selling_price - $data->product->discount); ?>TK</td>
        <td class="text-center">
            <button class="btn btn-danger btn-sm deleteData" data-cart_id = <?php echo e($data->id); ?>><i class="las la-trash-alt"></i></button>
        </td>
    <tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr>
        <td>
            <span><?php echo app('translator')->get('Data Not Found'); ?></span>
        </td>
    </tr>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\task-app\app\views/template/pos/pos_includes/table.blade.php ENDPATH**/ ?>