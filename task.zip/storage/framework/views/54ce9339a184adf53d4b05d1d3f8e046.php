;
<?php $__env->startSection('content'); ?>
    <p class="custom_text">Product Add Section</p>
    <form action="<?php echo e(route('product.store')); ?>" method="post"enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row p-5 product_section">
            <div class="col-md-6 col-sm-12">
                <label for="name">Product Name:</label>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <br>
                <input type="text" class="form-control" id="name" name="name"><br><br>
            </div>

            <div class="col-md-6 col-sm-12">
                <label for="product_unit">Product Unit:</label><br>
                <select class="form-select" id="product_unit" name="product_unit">
                    <option value="kg">KG</option>
                    <option value="litter">Litter</option>
                    <option value="Pieces">Pieces</option>
                </select>
            </div>
            <div class="col-md-6 col-sm-12">
                <label for="product_unit_value">Product Unit Value:</label>
                <?php $__errorArgs = ['product_unit_value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <br>
                <input type="number" class="form-control" id="product_unit_value" name="product_unit_value"><br><br>
            </div>

            <div class="col-md-6 col-sm-12">
                <label for="selling_price">Selling Price:</label>
                <?php $__errorArgs = ['selling_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <br>
                <input type="number" class="form-control" id="selling_price" name="selling_price"><br><br>
            </div>

            <div class="col-md-6 col-sm-12">
                <label for="purchase_price">Purchase Price:</label>
                <?php $__errorArgs = ['purchase_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <br>
                <input type="number" class="form-control" id="purchase_price" name="purchase_price"><br><br>
            </div>

            <div class="col-md-6 col-sm-12">
                <label for="discount">Discount</label><br>
                <input type="number" class="form-control" id="discount" name="discount"><br><br>
            </div>

            <div class="col-md-6 col-sm-12">
                <label for="tax">Tax(%):</label>
                <?php $__errorArgs = ['tax'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <br>
                <input type="number" class="form-control" id="tax" name="tax"><br><br>
            </div>

            <div class="col-md-6 col-sm-12">
                <label for="image">Image:</label>
                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <br>
                <p><input type="file" accept="image/*" name="image" id="file" onchange="loadFile(event)"></p>
                <p><img id="output" width="200" /></p>
            </div>
        </div>

        <div class="d-flex justify-content-end p-3">
            <button type="submit" class="btn btn-success">Submit</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<script>
        var loadFile = function(event) {
            var image = document.getElementById('output');
            image.src = URL.createObjectURL(event.target.files[0]);
        }
</script>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\task-app\app\views/template/product/create.blade.php ENDPATH**/ ?>