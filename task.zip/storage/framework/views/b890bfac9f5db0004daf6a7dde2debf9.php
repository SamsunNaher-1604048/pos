<header class="header">
    <div class="container-fluid">
        <div class="row p-2 align-items-center">
            <div class="get_date">
                <p class="fs-5">Today Date: <?php echo date("Y/m/d") ?></p>
            </div>
        </div>
    </div>
</header>
<?php /**PATH C:\xampp\htdocs\task-app\app\views/template/pos/pos_includes/header.blade.php ENDPATH**/ ?>